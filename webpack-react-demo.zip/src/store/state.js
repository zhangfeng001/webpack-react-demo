/*
 * @Descripttion: 
 * @version: 
 * @Author: lzy
 * @Date: 2021-04-12 14:42:46
 * @LastEditors: Andy
 * @LastEditTime: 2021-04-12 14:42:47
 */
// 声明默认值
// 这里我们列举两个示例
// 同步数据：pageTitle
// 异步数据：infoList（将来用异步接口获取）
export default {
    pageTitle: '首页',
    infoList: []
}